<html lang="en">
<head>
  <meta charset="utf-8" />
 	<title>Hello World!</title>
 	<link rel="stylesheet" href="hw.css">
</head>
 
<body>
  <div class="mainBox">
  	<div class="textBox">
  		<h1>Hello World!</h1>
  	</div>
	<!--  start table-content  -->
			<div id="table-content">

<?php

# Get the instance ID from meta-data and store it in the $instance_id variable
  $url = "http://169.254.169.254/latest/meta-data/instance-id";
  $instance_id = file_get_contents($url);
# Get the instance's availability zone from metadata and store it in the $zone variable
  $url = "http://169.254.169.254/latest/meta-data/placement/availability-zone";
  $zone = file_get_contents($url);
  
  # Print the data

?>
			<H1><center>
				<br/>
				<p>EC2 Instance <b><?php echo $instance_id; ?></b> in <b><?php echo $zone; ?></b>.	</p>
		
			</center></H1>
			</div>
			<!--  end table-content  -->
	
			<div class="clear"></div>
		 
		</div>
		<!--  end content-table-inner ............................................END  -->
  </div>
</body>
</html>
